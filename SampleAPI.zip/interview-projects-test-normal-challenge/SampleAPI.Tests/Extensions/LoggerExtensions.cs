﻿using Microsoft.Extensions.Logging;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SampleAPI.Tests.Extensions
{
    public static class LoggerExtensions
    {
        public static void VerifyLoggerCall<T>(this Mock<ILogger<T>> logger,
            LogLevel level,
            Times? times = null,
            Func<object, Type, bool>  messageValidation = null,
            EventId? eventId= null,
            Exception exception =null)
        {
            logger.Verify(m => m.Log(It.Is<LogLevel>(l => l == level),
                It.Is<EventId>(evt => eventId == null|| evt == eventId),
                It.Is<It.IsAnyType>((v,t) => messageValidation == null|| messageValidation(v, t)),
                It.Is<Exception>(ex => exception == null || ex == exception),
                It.Is<Func<It.IsAnyType, Exception, string>>((v,t) => true)), times ?? Times.Once());
                
        }
    }
}
