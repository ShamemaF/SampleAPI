using AutoFixture;
using FluentAssertions;
using FluentAssertions.Extensions;
using Microsoft.Extensions.Logging;
using Moq;
using SampleAPI.Entities;
using SampleAPI.Repositories;
using SampleAPI.Requests;
using SampleAPI.Tests.Extensions;

namespace SampleAPI.Tests.Repositories
{
    public class OrderRepositoryTests
    {
        private readonly OrderRepository _orderRepository;
        private readonly IFixture _fixture = new Fixture();
        private readonly Mock<ILogger<OrderRepository>> _logger;
        private readonly Mock<SampleApiDbContext> _context;

        public OrderRepositoryTests()
        {
            _logger = new Mock<ILogger<OrderRepository>>();
            _context= new Mock<SampleApiDbContext>();
            _orderRepository = new OrderRepository(_context.Object, _logger.Object);
        }

        [Fact]
        public async Task GetOrdersSuccess()
        {
            var result = await _orderRepository.GetRecentOrders();
            Assert.NotNull(result);
        }

        [Fact]
        public void GetOrdersException()
        {
            Task<Exception> actual = Assert.ThrowsAsync<Exception
                >(async () => await _orderRepository.GetRecentOrders());

            Assert.NotNull(actual);
            _logger.VerifyLoggerCall(LogLevel.Error, Times.Once());
        }

        [Fact]
        public async Task AddNewOrderSuccess()
        {
            var request = _fixture.Build<Order>().Create();
            var result = await _orderRepository.AddNewOrder(request);
            Assert.Equal(request.Id, result.Id);
        }

        [Fact]
        public void AddNewOrderException()
        {
            Task<Exception> actual = Assert.ThrowsAsync<Exception
                >(async () => await _orderRepository.AddNewOrder(_fixture.Build<Order>().Create()));

            Assert.NotNull(actual);
            _logger.VerifyLoggerCall(LogLevel.Error, Times.Once());
        }

        [Fact]
        public async Task GetOrdersInRangeSucess()
        {
            var result = await _orderRepository.GetOrdersInRange(5);
            Assert.NotNull(result);
        }
    }
}