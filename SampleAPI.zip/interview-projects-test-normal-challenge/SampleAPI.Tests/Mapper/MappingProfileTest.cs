﻿using AutoFixture;
using AutoMapper;
using SampleAPI.Entities;
using SampleAPI.Mapper;
using SampleAPI.Requests;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SampleAPI.Tests.Mapper
{
    public class MappingProfileTest
    {
        private static IMapper _mapper;

        private readonly IFixture fixture = new Fixture();

        public MappingProfileTest()
        {
            var mappingConfig = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile<MappingProfile>();
                cfg.AddGlobalIgnore("");
            });
            _mapper = mappingConfig.CreateMapper();
        }

        [Fact]
        public void ValidateMappingConfiguration()
        {
            _mapper.ConfigurationProvider.AssertConfigurationIsValid();
        }

        [Fact]
        public void ValidateOrderRequestWithOrder()
        {
            var request = fixture.Create<CreateOrderRequest>();
            var result= _mapper.Map<CreateOrderRequest, Order>(request);
            Assert.Equal(request.Id, result.Id);
        }

        [Fact]
        public void ValidateOrderWithOrderRequest()
        {
            var request = fixture.Create<Order>();
            var result = _mapper.Map<Order, CreateOrderRequest>(request);
            Assert.Equal(request.Id, result.Id);
        }
    }
}
