﻿using AutoFixture;
using AutoMapper;
using FluentAssertions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using SampleAPI.Controllers;
using SampleAPI.Entities;
using SampleAPI.Repositories;
using SampleAPI.Requests;

namespace SampleAPI.Tests.Controllers
{
    public class OrdersControllerTests
    {
        private readonly OrdersController _ordersController;
        private readonly IFixture _fixture = new Fixture();
        private readonly Mock<IMapper> _mapper;
        private readonly Mock<IOrderRepository> _repository;

        public OrdersControllerTests()
        {
            _repository = new Mock<IOrderRepository>();
            _mapper = new Mock<IMapper>();
            _ordersController = new(_repository.Object, _mapper.Object);
        }
        [Fact]
        public async Task GetAllOrdersSuccess()
        {
            var orders = _fixture.Build<Order>().CreateMany();
            _repository.Setup(x => x.GetRecentOrders()).ReturnsAsync(orders.ToList());
            var result = await _ordersController.GetOrders();

            result.Should().NotBeNull();
            var objectResult = (OkObjectResult)result.Result;
            var createdOrder = (List<Order>)objectResult.Value;
            createdOrder.Count.Should().Be(orders.Count());
        }

        [Fact]
        public async Task SubmitOrderSucceed()
        {
            var ordersRequest = _fixture.Build<CreateOrderRequest>().Create();
            var order= _fixture.Build<Order>().Create();

            _repository.Setup(x => x.AddNewOrder(order)).ReturnsAsync(order);
            await _ordersController.SubmitOrder(ordersRequest);

            _repository.Verify(x => x.AddNewOrder(It.IsAny<Order>()), Times.Once);
        }

        [Fact]
        public async Task GetAllOrdersWithinDateRangeSuccess()
        {
            var orders = _fixture.Build<Order>().CreateMany();
            _repository.Setup(x => x.GetOrdersInRange(It.IsAny<int>())).ReturnsAsync(orders.ToList());
            var result = await _ordersController.GetOrdersInRange(5);

            result.Should().NotBeNull();
        }
    }
}
