﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using SampleAPI.Entities;
using SampleAPI.Repositories;
using SampleAPI.Requests;

namespace SampleAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class OrdersController : ControllerBase
    {
        private readonly IOrderRepository _orderRepository;
        private readonly IMapper _mapper;

        public OrdersController(IOrderRepository orderRepository, IMapper mapper)
        {
            _orderRepository = orderRepository;
            _mapper= mapper;
        }
 
        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<List<Order>>> GetOrders()
        {
            var result = await _orderRepository.GetRecentOrders();
            return Ok(result);
        }

        [HttpPost]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> SubmitOrder([FromBody] CreateOrderRequest orderRequest)
        {
            if(orderRequest.EntryDate == DateTime.MinValue)
            {
                orderRequest.EntryDate = DateTime.Now;
            }
            var newOrder = _mapper.Map<Order>(orderRequest);
            var result = await _orderRepository.AddNewOrder(newOrder);
            return StatusCode(StatusCodes.Status201Created, result);
        }

        [HttpGet]
        [Route("/{daysRange}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> GetOrdersInRange([FromRoute]int daysRange)
        {
            var result = await _orderRepository.GetOrdersInRange(daysRange);
            return StatusCode(StatusCodes.Status200OK, result.ToList());
        }
    }
}
