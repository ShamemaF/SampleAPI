﻿using Swashbuckle.AspNetCore.Annotations;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace SampleAPI.Requests
{
    public class CreateOrderRequest
    {
        [JsonIgnore]
        [SwaggerSchema(ReadOnly = true)]
        public Guid Id { get; set; }

        [Required(ErrorMessage ="Name is required")]
        [MaxLength(100, ErrorMessage = "name Exceeds 100 character")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Entry Date is required")]
        public DateTime EntryDate { get; set; }

        [MaxLength(100, ErrorMessage = "Description Exceeds 100 character")]
        public string Description { get; set; }

        [DefaultValue(true)]
        public bool IsInvoiced { get; set; }

        [DefaultValue(false)]
        public bool IsDeleted { get; set; }

        public CreateOrderRequest(string name, DateTime entryDate, string description, bool isInvoiced, bool isDeleted)
        {
            Id = Guid.NewGuid();
            Name = name;
            EntryDate = entryDate;
            Description = description;
            IsInvoiced = isInvoiced;
            IsDeleted = isDeleted;

        }
    }
}
