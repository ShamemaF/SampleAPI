﻿using FluentDateTime;
using SampleAPI.Entities;

namespace SampleAPI.Repositories
{
    public class OrderRepository : IOrderRepository
    {
        private readonly SampleApiDbContext _context;

        private readonly ILogger<OrderRepository> _logger;
        public OrderRepository(SampleApiDbContext context, ILogger<OrderRepository> logger)
        {
            _context = context;
            _logger = logger;
        }

        public async Task<Order> AddNewOrder(Order newOrder)
        {
            try
            {
                await Task.Run(() => _context.Orders.AddAsync(newOrder));
                await _context.SaveChangesAsync();
            }
            catch (Exception e)
            {
                _logger.LogError(e, "Excepion in crating order {e}", e.Message);
            }
            return newOrder;
        }

        public async Task<List<Order>> GetRecentOrders()
        {
            var result = new List<Order>();
            try
            {
                result = await Task.Run(() => _context.Orders.ToList());
                result = result.Where(x => !x.IsDeleted).OrderByDescending(cont => cont.EntryDate).ToList();
            }
            catch (Exception e)
            {
                _logger.LogError(e, "Excepion is getting order {e}", e.Message);
            }
            return result;

        }

        public async Task<List<Order>> GetOrdersInRange(int daysRange)
        {
            var previousDatetime = DateTime.Now.SubtractBusinessDays(daysRange);
            var result = await GetRecentOrders();
            return result.Where(x => x.EntryDate >= previousDatetime && x.EntryDate <= DateTime.Now).ToList();
        }
    }
}
