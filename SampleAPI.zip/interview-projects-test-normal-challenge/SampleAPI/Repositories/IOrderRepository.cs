﻿using SampleAPI.Entities;
using SampleAPI.Requests;

namespace SampleAPI.Repositories
{
    public interface IOrderRepository
    {
        public Task<List<Order>> GetRecentOrders();
        public Task<Order> AddNewOrder(Order newOrder);

        Task<List<Order>> GetOrdersInRange(int daysRange);





    }
}
