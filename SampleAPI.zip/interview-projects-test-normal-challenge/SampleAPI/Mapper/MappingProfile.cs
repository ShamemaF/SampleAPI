﻿using AutoMapper;
using SampleAPI.Entities;
using SampleAPI.Requests;

namespace SampleAPI.Mapper
{
    public class MappingProfile : Profile
    {
        public MappingProfile() {
            CreateMap<Order, CreateOrderRequest>().ReverseMap();
        }
    }
}
